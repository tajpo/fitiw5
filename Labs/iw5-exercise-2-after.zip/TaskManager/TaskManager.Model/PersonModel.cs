﻿using System;
using System.Collections.ObjectModel;

using TaskManager.Model.Base.Implementation;

namespace TaskManager.Model
{
    public class PersonModel : BaseModel
    {
        public string Firstname { get; set; }

        public string Lastname { get; set; }

        public override string Name
        {
            get
            {
                return string.Format("{0} {1}", this.Firstname, this.Lastname);
            }
        }

        public ObservableCollection<TaskModel> Tasks { get; private set; }

        public PersonModel()
        {
            this.Tasks = new ObservableCollection<TaskModel>();
        }

        public PersonModel(Guid id)
            : base(id)
        {
        }
    }
}