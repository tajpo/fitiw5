﻿using System;

using TaskManager.Model.Base.Interface;

namespace TaskManager.Model.Base.Implementation
{
    public class BaseModel : IModel, IDescriptionModel, INameModel
    {
        public virtual string Description { get; set; }

        public Guid Id { get; private set; }

        public virtual string Name { get; set; }

        protected BaseModel()
        {
            this.Id = Guid.NewGuid();
        }

        protected BaseModel(Guid id)
        {
            this.Id = id;
        }
    }
}