﻿namespace TaskManager.Model.Base.Interface
{
    public interface INameModel
    {
        string Name { get; }
    }
}