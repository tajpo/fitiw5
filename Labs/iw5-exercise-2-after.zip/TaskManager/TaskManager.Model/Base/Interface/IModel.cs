﻿using System;

namespace TaskManager.Model.Base.Interface
{
    public interface IModel
    {
        Guid Id { get; }
    }
}