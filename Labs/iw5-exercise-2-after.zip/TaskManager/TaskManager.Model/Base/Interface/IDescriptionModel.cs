﻿namespace TaskManager.Model.Base.Interface
{
    public interface IDescriptionModel
    {
        string Description { get; set; }
    }
}