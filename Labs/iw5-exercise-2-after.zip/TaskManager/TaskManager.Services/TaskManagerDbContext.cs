﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using TaskManager.Model;

namespace TaskManager.Services
{
    public class TaskManagerDbContext : DbContext
    {
        public DbSet<PersonModel> Persons { get; set; }

        public DbSet<TaskModel> Tasks { get; set; }

        public TaskManagerDbContext()
            : base(@"Data Source=(LocalDB)\v11.0; AttachDbFileName=absolutniCesta\LocalDatabase.mdf;Persist Security Info=True;MultipleActiveResultSets=True;Integrated Security=SSPI")
        {
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<TaskManagerDbContext, TaskManagerDbMigrationsConfiguration<TaskManagerDbContext>>());
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<PersonModel>().ToTable("Persons");

            modelBuilder.Entity<TaskModel>().ToTable("Tasks");
            modelBuilder.Entity<TaskModel>().HasOptional(t => t.ParentTask).WithMany(t => t.Tasks);
        }

        public void FixEfProviderServicesProblem()
        {
            var instance = System.Data.Entity.SqlServer.SqlProviderServices.Instance;
        }
    }
}