namespace TaskManager.Services.Migrations
{
    using System;
    using System.Data.Entity.Migrations;

    public partial class Initialmigration : DbMigration
    {
        public override void Down()
        {
            this.DropForeignKey("dbo.Tasks", "ParentTask_Id", "dbo.Tasks");
            this.DropForeignKey("dbo.Tasks", "Assign_Id", "dbo.Persons");
            this.DropIndex("dbo.Tasks", new[] { "ParentTask_Id" });
            this.DropIndex("dbo.Tasks", new[] { "Assign_Id" });
            this.DropTable("dbo.Tasks");
            this.DropTable("dbo.Persons");
        }

        public override void Up()
        {
            this.CreateTable(
                "dbo.Persons",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        Firstname = c.String(),
                        Lastname = c.String(),
                        Description = c.String(),
                    })
                .PrimaryKey(t => t.Id);

            this.CreateTable(
                "dbo.Tasks",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        PercentDone = c.Int(nullable: false),
                        Description = c.String(),
                        Name = c.String(),
                        Assign_Id = c.Guid(),
                        ParentTask_Id = c.Guid(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Persons", t => t.Assign_Id)
                .ForeignKey("dbo.Tasks", t => t.ParentTask_Id)
                .Index(t => t.Assign_Id)
                .Index(t => t.ParentTask_Id);
        }
    }
}