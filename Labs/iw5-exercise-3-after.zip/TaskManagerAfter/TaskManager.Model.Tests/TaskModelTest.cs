﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;
using TaskManager.Model.Persons;
using TaskManager.Model.Tasks;

namespace TaskManager.Model.Tests
{
    [TestClass]
    public class TaskModelTest
    {
        [TestMethod]
        public void TestAddFirstTask()
        {
            var task = new TaskModel();
            const string name = "Testovací task";
            const string subTaskName = "Testovací subtask";
            task.Name = name;
            task.Tasks.Add(new TaskModel { Name = subTaskName });
            Assert.AreEqual(subTaskName, task.Tasks.First().Name);
        }

        [TestMethod]
        public void TestAddTaskToSimpleTask()
        {
            var task = new TaskModel();
            string name = "Testovací task";
            task.Name = name;
            task.Tasks.Add(new TaskModel());
            Assert.AreEqual(1, task.Tasks.Count);
        }

        [TestMethod]
        public void TestCreateSimpleTaskWithID()
        {
            Guid id = Guid.NewGuid();
            var task = new TaskModel(id);
            Assert.AreEqual(id, task.ID);
        }

        [TestMethod]
        public void TestSetNameAfterAddTaskToSimpleTask()
        {
            var task = new TaskModel();
            string name = "Testovací task";
            task.Name = name;
            task.Tasks.Add(new TaskModel());
            Assert.AreEqual(name, task.Name);
        }

        [TestMethod]
        public void TestSetPercentToTaskGroup()
        {
            var task = new TaskModel { Name = "Testovací task" };
            var task1 = new TaskModel { Name = "Testovací subtask 1", PercentDone = 60 };
            var task2 = new TaskModel { Name = "Testovací subtask 2", PercentDone = 40 };
            var task3 = new TaskModel { Name = "Testovací subtask 3", PercentDone = 50 };
            task.Tasks.Add(task1);
            task.Tasks.Add(task2);
            task.Tasks.Add(task3);

            int percentDone = 90;
            task.PercentDone = percentDone;
            Assert.IsTrue(task.Tasks.All(subtask => subtask.PercentDone == percentDone));
        }

        [TestMethod]
        public void TestSimpleTaskDoneFalse()
        {
            var task = new TaskModel { Name = "Testovací task", PercentDone = 85 };
            Assert.IsFalse(task.Done);
        }

        [TestMethod]
        public void TestSimpleTaskDoneTrue()
        {
            var task = new TaskModel { Name = "Testovací task", PercentDone = 100 };
            Assert.IsTrue(task.Done);
        }

        [TestMethod]
        public void TestSimpleTaskSetPercentOver100()
        {
            var task = new TaskModel { Name = "Testovací task", PercentDone = 155 };
            Assert.AreEqual(100, task.PercentDone);
        }

        [TestMethod]
        public void TestSimpleTaskSetPercentUnder0()
        {
            var task = new TaskModel { Name = "Testovací task", PercentDone = -5 };
            Assert.AreEqual(0, task.PercentDone);
        }

        [TestMethod]
        public void TestTaskGroupPercentDoneCalculate()
        {
            var task = new TaskModel { Name = "Testovací task" };
            var task1 = new TaskModel { Name = "Testovací subtask 1", PercentDone = 60 };
            var task2 = new TaskModel { Name = "Testovací subtask 2", PercentDone = 40 };
            var task3 = new TaskModel { Name = "Testovací subtask 3", PercentDone = 50 };
            task.Tasks.Add(task1);
            task.Tasks.Add(task2);
            task.Tasks.Add(task3);

            Assert.AreEqual(50, task.PercentDone);
        }

        [TestMethod]
        public void TestTaskRemove()
        {
            var task = new TaskModel { Name = "Testovací task" };
            var task1 = new TaskModel { Name = "Testovací subtask 1", PercentDone = 60 };
            task.Tasks.Add(task1);
            task.Tasks.Remove(task1);
            Assert.AreEqual(0, task.Tasks.Count);
        }

        [TestMethod]
        public void TestTaskRemoveAndConvertToSimpleTask()
        {
            var task = new TaskModel { Name = "Testovací task" };
            var task1 = new TaskModel { Name = "Testovací subtask 1", PercentDone = 60 };
            var task2 = new TaskModel { Name = "Testovací subtask 2", PercentDone = 40 };
            task.Tasks.Add(task1);
            task.Tasks.Add(task2);
            task.Tasks.Remove(task1);
            Assert.AreEqual(40, task.PercentDone);
        }
    }
}