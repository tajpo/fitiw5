﻿using System;

using TaskManager.Model.Persons;
using TaskManager.Services.Services.Repository;

namespace TaskManager.Services.Services
{
    public class PersonService : Repository<TaskManagerDbContext, PersonModel>
    {
    }
}