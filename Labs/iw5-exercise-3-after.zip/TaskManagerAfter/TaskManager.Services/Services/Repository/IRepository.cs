using System;
using System.Collections.ObjectModel;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Linq;
using System.Linq.Expressions;

using TaskManager.Model.Base.Interface;

namespace TaskManager.Services.Services.Repository
{
    public interface IRepository<T>
        where T : class, IModel
    {
        T Add(T entity);

        void Delete(T entity);

        void Dispose();

        void Edit(T entity);

        IQueryable<T> FindBy(Expression<Func<T, bool>> predicate);

        IQueryable<T> GetAll();

        T GetByID(Guid id);

        ObservableCollection<T> GetObservableCollection();

        void LoadAll();

        void Save();
    }
}