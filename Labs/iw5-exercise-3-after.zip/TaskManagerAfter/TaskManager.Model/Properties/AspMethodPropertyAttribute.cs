using System;
using System.Diagnostics;

namespace TaskManager.Model.Properties
{
    [AttributeUsage(AttributeTargets.Property)]
    [Conditional("JETBRAINS_ANNOTATIONS")]
    public sealed class AspMethodPropertyAttribute : Attribute
    {
    }
}