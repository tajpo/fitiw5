using System;
using System.Diagnostics;

namespace TaskManager.Model.Properties
{
    [AttributeUsage(AttributeTargets.Assembly, AllowMultiple = true)]
    [Conditional("JETBRAINS_ANNOTATIONS")]
    public sealed class RazorInjectionAttribute : Attribute
    {
        public RazorInjectionAttribute(string type, string fieldName)
        {
            this.Type = type;
            this.FieldName = fieldName;
        }

        public string FieldName { get; private set; }

        public string Type { get; private set; }
    }
}