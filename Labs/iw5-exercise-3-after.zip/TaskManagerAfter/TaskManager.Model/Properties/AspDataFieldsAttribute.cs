using System;
using System.Diagnostics;

namespace TaskManager.Model.Properties
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Method)]
    [Conditional("JETBRAINS_ANNOTATIONS")]
    public sealed class AspDataFieldsAttribute : Attribute
    {
    }
}