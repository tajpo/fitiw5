using System;

using TaskManager.Model.Base.Interface;

namespace TaskManager.Model.Base.Implementation
{
    public abstract class BaseModel : Model, INameModel, IDescriptionModel
    {
        public virtual string Description { get; set; }

        public virtual string Name { get; set; }

        protected BaseModel()
        {
        }

        protected BaseModel(Guid id)
            : base(id)
        {
        }

        protected int ClipToRange(int min, int max, int value)
        {
            if (value > max)
            {
                return max;
            }
            if (value < min)
            {
                return min;
            }
            return value;
        }
    }
}