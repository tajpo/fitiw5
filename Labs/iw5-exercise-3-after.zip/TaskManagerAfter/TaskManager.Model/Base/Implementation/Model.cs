﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

using TaskManager.Model.Base.Interface;
using TaskManager.Model.Properties;

namespace TaskManager.Model.Base.Implementation
{
    public abstract class Model : IModel
    {
        public Guid ID { get; private set; }

        protected Model()
        {
            this.ID = Guid.NewGuid();
        }

        protected Model(Guid id)
        {
            this.ID = id;
        }
    }
}