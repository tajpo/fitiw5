﻿using System;
using System.ComponentModel;

namespace TaskManager.Model.Base.Interface
{
    public interface IModel
    {
        Guid ID { get; }
    }
}