﻿using TaskManager.Model.Persons;
using TaskManager.Services.Services;

namespace TaskManager.Console
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            using (var personService = new PersonService())
            {
                var person = new PersonModel { Firstname = "Petr", Lastname = "Horák" };
                personService.Add(person);
                personService.Save();
            }
        }
    }
}