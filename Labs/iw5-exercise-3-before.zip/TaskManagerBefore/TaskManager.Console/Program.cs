﻿using TaskManager.Model.Persons;
using TaskManager.Services;
using TaskManager.Services.Services;
using TaskManager.Services.Services.Repository;

namespace TaskManager.Console
{
    internal class Program
    {
        private static void Main(string[] args)
        {
        }
    }
}