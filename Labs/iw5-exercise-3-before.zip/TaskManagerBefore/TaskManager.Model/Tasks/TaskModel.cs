using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;

using TaskManager.Model.Base.Implementation;
using TaskManager.Model.Persons;

namespace TaskManager.Model.Tasks
{
    public class TaskModel : BaseModel
    {
        private int percentDone;

        public PersonModel Assign { get; set; }

        public bool Done
        {
            get
            {
                return this.PercentDone == 100;
            }
        }

        public bool IsMainTask
        {
            get
            {
                return this.ParentTask == null;
            }
        }

        public virtual TaskModel ParentTask { get; set; }

        public int PercentDone
        {
            get
            {
                if (this.Tasks.Any())
                {
                    return this.Tasks.Sum(task => task.PercentDone) / this.Tasks.Count;
                }

                return this.percentDone;
            }
            set
            {
                if (this.percentDone != value)
                {
                    this.percentDone = value;
                }
            }
        }

        public virtual ObservableCollection<TaskModel> Tasks { get; private set; }

        public TaskModel()
        {
            this.Tasks = new ObservableCollection<TaskModel>();
        }

        public TaskModel(Guid id)
            : base(id)
        {
            this.Tasks = new ObservableCollection<TaskModel>();
        }
    }
}