﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using TaskManager.Model.Persons;
using TaskManager.Model.Tasks;
using TaskManager.Services.Services;
using TaskManager.Services.Services.Repository;

namespace TaskManager.Services.Tests
{
    [TestClass]
    public class ServiceTest
    {
        private readonly Repository<TaskManagerDbContext, TaskModel> repository = new Repository<TaskManagerDbContext, TaskModel>();
        private Guid idOfMainTask;

        [TestInitialize]
        public void Init()
        {
            using (var context = new TaskManagerDbContext())
            {
                this.RemoveDataFromDatabase(context);

                this.InitializeDatabaseWithTestData(context);
            }
        }

        [TestMethod]
        public void TestServiceGetAll()
        {
            var tasks = this.repository.GetAll();
            List<TaskModel> taskList = tasks.ToList();
            Assert.IsTrue(taskList.Any());
        }

        [TestMethod]
        public void TestServiceGetById()
        {
            var task = this.GetMainTask();
            Assert.AreEqual("Testovací task", task.Name);
        }

        [TestMethod]
        public void TestServiceGetItem()
        {
            var task = this.GetMainTask();
            Assert.AreEqual(this.idOfMainTask, task.ID);
        }

        [TestMethod]
        public void TestServiceGetSubTasks()
        {
            var task = this.GetMainTask();
            Assert.AreEqual(2, task.Tasks.Count);
        }

        [TestMethod]
        public void TestServiceSubTaskHaveSetParrent()
        {
            var task = this.repository.GetByID(this.idOfMainTask);
            var subTask = task.Tasks.First();
            Assert.IsNotNull(subTask.ParentTask);
        }

        private TaskModel GetMainTask()
        {
            return this.repository.GetByID(this.idOfMainTask);
        }

        private void InitializeDatabaseWithTestData(TaskManagerDbContext context)
        {
            this.idOfMainTask = new Guid();
            var task = new TaskModel(this.idOfMainTask) { Name = "Testovací task" };
            var task1 = new TaskModel { Name = "Testovací subtask 1", PercentDone = 60 };
            var task2 = new TaskModel { Name = "Testovací subtask 2", PercentDone = 40 };

            task.Tasks.Add(task1);
            task.Tasks.Add(task2);
            var person = new PersonModel { Firstname = "Petr", Lastname = "Horák" };
            person.Tasks.Add(task);

            context.Persons.Add(person);
            context.SaveChanges();
        }

        private void RemoveDataFromDatabase(TaskManagerDbContext context)
        {
            if (this.repository.GetAll().Any())
            {
                foreach (var task in context.Tasks)
                {
                    context.Tasks.Remove(task);
                }
                foreach (var person in context.Persons)
                {
                    context.Persons.Remove(person);
                }
                context.SaveChanges();
            }
        }
    }
}